# Learnly - Real-Time Firebase Authentication User Deletion Tool

This tool is built for **Google Play Store Account Deletion Compliance**. It permanently removes registered user accounts from **Firebase Authentication** (`console.firebase.google.com/project/learnly-a90fb/authentication/users`) as well as **Cloud Firestore**.

---

## 🔍 Why Was The User Still Showing in Firebase Authentication Earlier?

- **Firebase Authentication** (`Authentication > Users` tab) and **Cloud Firestore** (`users` collection) are two separate databases inside Firebase.
- Client-side code (`deleteDoc`) only deleted the profile record in Firestore.
- Google Play Reviewers and the Firebase Console **Authentication tab** verify the actual Auth account! To delete an account from the Authentication tab, **Firebase Admin SDK** (`admin.auth().deleteUser(uid)`) is required.
- This updated tool uses **Firebase Admin SDK** to delete the account from **BOTH Firebase Authentication AND Firestore** in real-time!

---

## 🔑 Step 1: Add Your Firebase Service Account Key (10 Seconds)

To give the tool administrative permission to delete users from the Firebase Authentication tab:

1. Open your [Firebase Console](https://console.firebase.google.com/project/learnly-a90fb/settings/serviceaccounts/adminsdk).
2. Go to **Project Settings** (click the ⚙️ Gear icon next to *Project Overview* in the top left).
3. Click the **Service accounts** tab.
4. Click the blue button: **"Generate new private key"**, then click **Generate key**.
5. Move or copy that downloaded `.json` file into this `learnly-user-manager` folder and rename it to:
   ```
   serviceAccountKey.json
   ```

---

## 💻 Step 2: Test Locally on localhost:3000

1. Open a terminal in this folder (`D:\N_B_TECH_CSE\Sem5\PA\Project\Learnly\learnly-user-manager`):
   ```bash
   node server.js
   ```
2. Open your browser at:
   ```
   http://localhost:3000
   ```
3. Enter any registered email (e.g. `nirav@example.com` or `arjun@gmail.com`).
4. Click **Delete User** and confirm.
5. Refresh your Firebase Console `Authentication > Users` tab — **the user will be permanently deleted!**

---

## ☁️ Step 3: Deploy to Vercel (For Google Play Review)

### Method A: Deploy via Vercel Web Dashboard (Recommended)
1. Go to [vercel.com](https://vercel.com) and log in.
2. Click **Add New... > Project**.
3. Import the `learnly-user-manager` directory (or drag & drop).
4. Under **Environment Variables**, add:
   - **Key**: `FIREBASE_SERVICE_ACCOUNT`
   - **Value**: *(Paste the entire contents of your `serviceAccountKey.json`)*
5. Click **Deploy**.
6. You will get a live URL (e.g. `https://learnly-user-manager.vercel.app`) that you can submit to Google Play Console as your official **Account Deletion URL**!

---

## 📁 File Structure

```
learnly-user-manager/
├── api/
│   ├── check-user.js        # Serverless function: Checks user in Firebase Auth
│   └── delete-user.js       # Serverless function: Deletes user from Firebase Auth & Firestore
├── firebase-admin-init.js   # Admin SDK initializer (reads key or env var)
├── server.js                # Local server for http://localhost:3000
├── index.html               # Clean 2-field UI (Email Input + Delete Button)
├── app.js                   # Connects UI to /api/check-user & /api/delete-user
├── style.css                # Custom styling
├── vercel.json              # Vercel serverless routing
└── package.json             # Node dependencies
```

---

## 👨‍💻 Project Information
- **Lead Developer**: Niravkumar Pranavkumar Jani (Enrollment: `92510120026`)
- **Department**: Computer Engineering, Marwadi University
- **Mentor**: Prof. Jigar Dave

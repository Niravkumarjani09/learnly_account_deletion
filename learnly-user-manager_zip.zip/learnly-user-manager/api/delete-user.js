const { getServiceAccount, getUserByEmail, deleteUserByUid } = require('../firebase-auth-admin');

module.exports = async (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const { email, uid } = req.body || {};
  if (!email && !uid) {
    return res.status(400).json({ error: "Email or UID parameter is required." });
  }

  const serviceAccount = getServiceAccount();
  if (!serviceAccount) {
    return res.status(503).json({
      error: "SERVICE_KEY_REQUIRED",
      message: "Please place 'serviceAccountKey.json' in learnly-user-manager folder to delete users from Firebase Authentication."
    });
  }

  try {
    let targetUid = uid;
    let targetEmail = email ? email.trim() : null;

    // Look up UID by email if not provided
    if (!targetUid && targetEmail) {
      const user = await getUserByEmail(targetEmail, serviceAccount);
      if (user) {
        targetUid = user.uid;
      } else {
        return res.status(404).json({ error: `User '${targetEmail}' was not found in Firebase Authentication.` });
      }
    }

    // Execute permanent deletion from Firebase Authentication & Firestore
    await deleteUserByUid(targetUid, serviceAccount);
    console.log(`User ${targetEmail || targetUid} permanently deleted from Firebase.`);

    return res.status(200).json({
      success: true,
      message: `User '${targetEmail || targetUid}' was permanently deleted from Firebase Authentication and Firestore database.`
    });

  } catch (err) {
    console.error("Delete user error:", err);
    return res.status(500).json({ error: err.message });
  }
};

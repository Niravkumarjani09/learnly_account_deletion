const { getServiceAccount, getUserByEmail } = require('../firebase-auth-admin');

module.exports = async (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const email = (req.body && req.body.email) || req.query.email;
  if (!email || !email.trim()) {
    return res.status(400).json({ error: "Email is required." });
  }

  const trimmedEmail = email.trim();
  const serviceAccount = getServiceAccount();

  if (!serviceAccount) {
    return res.status(503).json({
      error: "SERVICE_KEY_REQUIRED",
      message: "Please place 'serviceAccountKey.json' in learnly-user-manager folder to connect to Firebase Authentication."
    });
  }

  try {
    const user = await getUserByEmail(trimmedEmail, serviceAccount);

    if (user) {
      return res.status(200).json({
        exists: true,
        inAuth: true,
        user
      });
    } else {
      return res.status(200).json({
        exists: false,
        inAuth: false,
        message: `No user with email '${trimmedEmail}' found in Firebase Authentication.`
      });
    }
  } catch (err) {
    console.error("Check user error:", err);
    return res.status(500).json({ error: err.message });
  }
};
